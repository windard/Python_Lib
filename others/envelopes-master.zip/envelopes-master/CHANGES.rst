Envelopes Changelog
===================

Version 0.4
-----------

Published on 2013-11-10

* Closes `#10 <https://github.com/tomekwojcik/envelopes/issues/10>`_.
* Closes `#11 <https://github.com/tomekwojcik/envelopes/issues/11>`_.
* Closes `#12 <https://github.com/tomekwojcik/envelopes/issues/12>`_.
* Closes `#13 <https://github.com/tomekwojcik/envelopes/issues/13>`_.
* Closes `#15 <https://github.com/tomekwojcik/envelopes/issues/15>`_.
* Closes `#16 <https://github.com/tomekwojcik/envelopes/issues/15>`_.

Version 0.3
-----------

Published on 2013-08-19

* Closes `#6 <https://github.com/tomekwojcik/envelopes/issues/6>`_.
* Closes `#5 <https://github.com/tomekwojcik/envelopes/issues/5>`_.

Version 0.2
-----------

Published on 2013-08-10

* Closes `#3 <https://github.com/tomekwojcik/envelopes/issues/3>`_.
* Closes `#1 <https://github.com/tomekwojcik/envelopes/issues/1>`_.

Version 0.1.1
-------------

Published on 2013-08-06

* Fixes for PyPI.

Version 0.1
-----------

Published on 2013-08-06

* Initial version.
