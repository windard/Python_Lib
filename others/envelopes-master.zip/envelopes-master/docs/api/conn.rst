SMTP connection
===============

.. autoclass:: envelopes.conn.SMTP
    :members:
    :undoc-members:

.. autoclass:: envelopes.conn.GMailSMTP
    :members:
    :undoc-members:

.. autoclass:: envelopes.conn.SendGridSMTP
    :members:
    :undoc-members:

.. autoclass:: envelopes.conn.MailcatcherSMTP
    :members:
    :undoc-members:
