Envelope class
==============

.. autoclass:: envelopes.envelope.Envelope
    :members:
