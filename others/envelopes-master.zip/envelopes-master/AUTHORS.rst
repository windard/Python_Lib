Envelopes is written and maintained by Tomasz Wójcik and various contributors:

Lead Developer
==============

* `Tomasz Wójcik <https://github.com/tomekwojcik>`_

Patches and Suggestions
=======================

* `Carter Sande <https://github.com/carter-sande>`_
* `Paul Durivage <https://github.com/angstwad>`_
* `Ram Rachum <https://github.com/cool-RR>`_
* `Wade Simmons <https://github.com/wadey>`_
* `Adam Canady <https://github.com/AdamCanady>`_
* `Mark Lewandowski <https://github.com/mlew>`_
